// /scripts/popup.js

import { encryptMessage, decryptMessage } from './crypto.js';
import { loadEncryptionKey } from './storage.js';

document.addEventListener('DOMContentLoaded', function() {
    const encryptBtn = document.getElementById('encryptBtn');
    const decryptBtn = document.getElementById('decryptBtn');
    const optionsPageBtn = document.getElementById('optionsPageBtn');
    const loadingIndicator = document.getElementById('loading');
    const output = document.getElementById('output');
    const notification = document.getElementById('notification'); // New element for notifications

    // Function to show notification
    function showNotification(message) {
        notification.textContent = message;
        notification.style.display = 'block';
        setTimeout(() => {
            notification.style.display = 'none';
        }, 3000); // Hide after 3 seconds
    }

    // Function to detect current theme and notify background
    function detectAndNotifyTheme() {
        const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
        chrome.runtime.sendMessage({ action: "updateIcon", isDarkMode: isDarkMode }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Error sending message to background:", chrome.runtime.lastError);
            } else {
                console.log("Theme update message sent:", response.status);
            }
        });
    }

    // Detect theme on load
    detectAndNotifyTheme();

    // Listen for changes in the color scheme
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', (e) => {
        detectAndNotifyTheme();
    });

    encryptBtn.addEventListener('click', async function() {
        const message = document.getElementById('messageInput').value;
        if (message.trim() === "") {
            alert("Please enter a message!");
            return;
        }

        try {
            loadingIndicator.style.display = 'block';
            const encryptionKey = await loadEncryptionKey();
            const encrypted = await encryptMessage(message, encryptionKey);
            output.textContent = "Encrypted: " + encrypted;

            // Copy to clipboard
            await navigator.clipboard.writeText(encrypted);
            showNotification("Encrypted text copied to clipboard.");
        } catch (error) {
            console.error("Encryption failed:", error);
            output.textContent = "Encryption failed. " + error;
        } finally {
            loadingIndicator.style.display = 'none';
        }
    });

    decryptBtn.addEventListener('click', async function() {
        const encryptedMessage = document.getElementById('encryptedInput').value;
        if (encryptedMessage.trim() === "") {
            alert("Please enter an encrypted message!");
            return;
        }

        try {
            loadingIndicator.style.display = 'block';
            const encryptionKey = await loadEncryptionKey();
            const decrypted = await decryptMessage(encryptedMessage, encryptionKey);
            output.textContent = "Decrypted: " + decrypted;
        } catch (error) {
            console.error("Decryption failed:", error);
            output.textContent = "Decryption failed. " + error;
        } finally {
            loadingIndicator.style.display = 'none';
        }
    });

    optionsPageBtn.addEventListener('click', function() {
        chrome.runtime.openOptionsPage();
    });
});
