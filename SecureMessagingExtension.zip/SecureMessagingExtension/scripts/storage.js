// /scripts/storage.js

import { deriveKey } from './crypto.js';

// Define a fixed salt (must be the same across all installations)
const FIXED_SALT = "FixedSaltValue123"; // Choose a sufficiently random and secure value

// Function to load the encryption key from Chrome storage and derive the CryptoKey
export async function loadEncryptionKey() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['encryptionKey'], async function(result) {
            if (result.encryptionKey) {
                console.log("Key retrieved from storage.");
                try {
                    const encoder = new TextEncoder();
                    const salt = encoder.encode(FIXED_SALT); // Use fixed salt
                    const key = await deriveKey(result.encryptionKey, salt);
                    resolve(key);
                } catch (error) {
                    console.error("Key derivation error:", error);
                    reject("Key derivation failed");
                }
            } else {
                console.error("No key found in storage.");
                reject("Key not found");
            }
        });
    });
}

// Function to save the encryption key to Chrome storage
export async function saveEncryptionKey(rawKey) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.set({ 
            encryptionKey: rawKey 
        }, function() {
            if (chrome.runtime.lastError) {
                console.error("Error saving key:", chrome.runtime.lastError);
                reject("Failed to save key");
            } else {
                console.log("Encryption key saved to storage.");
                resolve();
            }
        });
    });
}

// Function to clear the encryption key from storage
export function clearEncryptionKey() {
    chrome.storage.local.remove(['encryptionKey'], function() {
        if (chrome.runtime.lastError) {
            console.error("Error clearing key:", chrome.runtime.lastError);
        } else {
            console.log("Encryption key cleared from storage.");
        }
    });
}
