// /scripts/crypto.js

// Function to derive a key using PBKDF2
export async function deriveKey(password, salt) {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );
    return crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
    );
}

// Function to encrypt the message using AES-GCM
export async function encryptMessage(message, encryptionKey) {
    try {
        const encoder = new TextEncoder();
        const encodedMessage = encoder.encode(message);  // Encode the message as a Uint8Array

        const iv = crypto.getRandomValues(new Uint8Array(12));  // Create a random initialization vector

        const encrypted = await crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            encryptionKey,
            encodedMessage  // Encrypt the message
        );

        const buffer = new Uint8Array(encrypted);
        const combined = new Uint8Array(iv.length + buffer.length);
        combined.set(iv);
        combined.set(buffer, iv.length);

        return btoa(String.fromCharCode(...combined));  // Return the Base64-encoded encrypted message
    } catch (error) {
        console.error("Encryption error:", error);  // Log any encryption errors
        throw error;
    }
}

// Function to decrypt the message using AES-GCM
export async function decryptMessage(encryptedMessage, encryptionKey) {
    try {
        // Decode the Base64 encrypted message
        const combined = new Uint8Array(atob(encryptedMessage).split("").map(char => char.charCodeAt(0)));

        // Extract the IV (first 12 bytes) and the encrypted content (remaining bytes)
        const iv = combined.slice(0, 12);  // First 12 bytes are the IV
        const encryptedContent = combined.slice(12);  // The rest is the encrypted message

        const decrypted = await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: iv  // Use the IV to decrypt
            },
            encryptionKey,
            encryptedContent
        );

        const decoder = new TextDecoder();
        return decoder.decode(decrypted);  // Return the decrypted message
    } catch (error) {
        console.error("Decryption error:", error);  // Log any decryption errors
        throw error;
    }
}
