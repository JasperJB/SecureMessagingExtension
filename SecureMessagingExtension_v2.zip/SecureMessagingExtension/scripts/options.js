// /scripts/options.js

import { saveEncryptionKey, clearEncryptionKey } from './storage.js';

document.addEventListener('DOMContentLoaded', function() {
    const codeFileInput = document.getElementById('codeFileInput');
    const clearKeyBtn = document.getElementById('clearKeyBtn');
    const status = document.getElementById('status');

    codeFileInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        
        if (file) {
            console.log("File selected:", file.name);

            const reader = new FileReader();
            reader.onload = async function(e) {
                const fileContent = e.target.result.trim();
                console.log("File content (key):", fileContent);

                // Validate key length (assuming minimum length, or handle as per deriveKey)
                if (fileContent.length < 8) { // Example: minimum length
                    console.error("Invalid key length:", fileContent.length);
                    status.textContent = "Invalid key length. The key must be at least 8 characters.";
                    status.classList.add('error');
                    return;
                }

                try {
                    await saveEncryptionKey(fileContent);
                    status.textContent = "Key successfully uploaded and saved!";
                    status.classList.remove('error');
                } catch (error) {
                    status.textContent = "Failed to save the key.";
                    status.classList.add('error');
                }

                // Reset the file input to allow re-uploading
                codeFileInput.value = '';  // Reset the input field
            };

            reader.onerror = function(e) {
                console.error("Error reading file:", e);
                status.textContent = "Error reading file. Please try again.";
                status.classList.add('error');
            };

            reader.readAsText(file);  // Read the file as text
        } else {
            status.textContent = "Please select a file.";
            status.classList.add('error');
        }
    });

    clearKeyBtn.addEventListener('click', function() {
        clearEncryptionKey();
        status.textContent = "Encryption key has been cleared.";
        status.classList.remove('error');
    });
});
