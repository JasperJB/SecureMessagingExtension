// /scripts/fileCrypto.js

// Function to encrypt an ArrayBuffer using AES-GCM
export async function encryptArrayBuffer(arrayBuffer, encryptionKey) {
    try {
        const iv = crypto.getRandomValues(new Uint8Array(12)); // Initialization vector

        const encrypted = await crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            encryptionKey,
            arrayBuffer
        );

        // Combine IV and encrypted data
        const ivAndEncrypted = new Uint8Array(iv.length + encrypted.byteLength);
        ivAndEncrypted.set(iv, 0);
        ivAndEncrypted.set(new Uint8Array(encrypted), iv.length);

        return ivAndEncrypted.buffer;
    } catch (error) {
        console.error("Encryption error:", error);
        throw error;
    }
}

// Function to decrypt an ArrayBuffer using AES-GCM
export async function decryptArrayBuffer(arrayBuffer, encryptionKey) {
    try {
        const data = new Uint8Array(arrayBuffer);
        const iv = data.slice(0, 12); // First 12 bytes are the IV
        const encryptedData = data.slice(12); // The rest is the encrypted content

        const decrypted = await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            encryptionKey,
            encryptedData
        );

        return decrypted; // Returns an ArrayBuffer
    } catch (error) {
        console.error("Decryption error:", error);
        throw error;
    }
}
