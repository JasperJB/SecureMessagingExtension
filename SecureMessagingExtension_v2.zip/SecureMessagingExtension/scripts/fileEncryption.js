// /scripts/fileEncryption.js

import { encryptArrayBuffer, decryptArrayBuffer } from './fileCrypto.js';
import { loadEncryptionKey } from './storage.js';

document.addEventListener('DOMContentLoaded', function() {
    const fileEncryptInput = document.getElementById('fileEncryptInput');
    const fileDecryptInput = document.getElementById('fileDecryptInput');
    const encryptFileBtn = document.getElementById('encryptFileBtn');
    const decryptFileBtn = document.getElementById('decryptFileBtn');
    const status = document.getElementById('status');
    const notification = document.getElementById('notification');

    // Function to show notifications
    function showNotification(message) {
        notification.textContent = message;
        notification.style.display = 'block';
        setTimeout(() => {
            notification.style.display = 'none';
        }, 3000); // Hide after 3 seconds
    }

    // Encrypt File
    encryptFileBtn.addEventListener('click', async function() {
        const file = fileEncryptInput.files[0];
        if (!file) {
            status.textContent = "Please select a file to encrypt.";
            status.classList.add('error');
            return;
        }

        try {
            status.textContent = "Encrypting file...";
            status.classList.remove('error');

            const encryptionKey = await loadEncryptionKey();

            const arrayBuffer = await file.arrayBuffer();
            const encryptedBuffer = await encryptArrayBuffer(arrayBuffer, encryptionKey);

            // Create a blob from the encrypted data
            const encryptedBlob = new Blob([encryptedBuffer], { type: 'application/octet-stream' });
            const downloadUrl = URL.createObjectURL(encryptedBlob);

            // Create a temporary link to trigger the download
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = file.name + '.encrypted';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(downloadUrl);

            showNotification("File encrypted and downloaded.");

        } catch (error) {
            console.error("File encryption failed:", error);
            status.textContent = "File encryption failed. " + error;
            status.classList.add('error');
        }
    });

    // Decrypt File
    decryptFileBtn.addEventListener('click', async function() {
        const file = fileDecryptInput.files[0];
        if (!file) {
            status.textContent = "Please select a file to decrypt.";
            status.classList.add('error');
            return;
        }

        try {
            status.textContent = "Decrypting file...";
            status.classList.remove('error');

            const encryptionKey = await loadEncryptionKey();

            const arrayBuffer = await file.arrayBuffer();
            const decryptedBuffer = await decryptArrayBuffer(arrayBuffer, encryptionKey);

            // Create a blob from the decrypted data
            const decryptedBlob = new Blob([decryptedBuffer]);
            const downloadUrl = URL.createObjectURL(decryptedBlob);

            // Create a temporary link to trigger the download
            const a = document.createElement('a');
            a.href = downloadUrl;
            // Remove the .encrypted extension if present
            let fileName = file.name.replace(/\.encrypted$/, '');
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(downloadUrl);

            showNotification("File decrypted and downloaded.");

        } catch (error) {
            console.error("File decryption failed:", error);
            status.textContent = "File decryption failed. " + error;
            status.classList.add('error');
        }
    });
});
