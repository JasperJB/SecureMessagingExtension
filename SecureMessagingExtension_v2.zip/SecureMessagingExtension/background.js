// background.js

console.log("Background script running...");

// Function to update the extension icon based on the current theme
function updateIcon(isDarkMode) {
    const iconPath = isDarkMode
        ? {
            "16": "icons/icon16dark.png",
            "48": "icons/icon48dark.png",
            "128": "icons/icon128dark.png"
          }
        : {
            "16": "icons/icon16light.png",
            "48": "icons/icon48light.png",
            "128": "icons/icon128light.png"
          };

    chrome.action.setIcon({ path: iconPath }, () => {
        if (chrome.runtime.lastError) {
            console.error("Error setting icon:", chrome.runtime.lastError);
        } else {
            console.log(`Icon updated to ${isDarkMode ? "dark" : "light"} theme.`);
        }
    });
}

// Listen for messages to update the icon
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updateIcon") {
        updateIcon(request.isDarkMode);
        sendResponse({ status: "Icon updated" });
    }
});

// Initialize icon on startup
chrome.runtime.onStartup.addListener(() => {
    chrome.runtime.sendMessage({ action: "getCurrentTheme" }, (response) => {
        if (response && typeof response.isDarkMode === "boolean") {
            updateIcon(response.isDarkMode);
        }
    });
});
